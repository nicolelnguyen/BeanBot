'''
to do list:
update functions - 
  - add_assignment
  - delete assignment
'''

import os
import discord
import requests
import json
import random
import time

from replit import db

#instance client is connection to discord
client = discord.Client()

#instance bot key
my_secret = os.environ['TOKEN']

#data structures
command = '!commands'
command_list = ['!greet', '!quote', '!add', '!del', '!list', '!break', '!msg']
command_description = [' = greets the user', ' = send the user a randomly generated motivation quote', ' = adds a new assignment to agenda', ' = deletes assignment from entered number', ' = prints out the list of assignments', ' = allows user to take a short break and play "Rock, Paper, Scissors"!', ' = tell BeanBot a message and BeanBot will reply back!' ]
game = ['Rock', 'Paper', 'Scissors']

#changes
assignmentList = []


#functions
def get_quote():
  response = requests.get("https://zenquotes.io/api/random")
  json_data = json.loads(response.text)
  quote = json_data[0]['q'] + " -" + json_data[0]['a']
  return quote

def update_agenda(assignment):   
  if "agenda" in db.keys():
    db["agenda"].append(assignment)
  else:
    db["agenda"] = [assignment]
  
def delete_assignment(index):
  agenda = db['agenda']
  if len(agenda) > index:
    del agenda[index]
    db['agenda'] = agenda
    

#bot ready to be used
@client.event
async def on_ready():
  print('We have logged in as {0.user}'.format(client))



@client.event
async def on_message(message):
  if message.author == client.user:
    return
  
  #greeting command
  if message.content.startswith(command_list[0]):
    await message.channel.send(f"Hello! {message.author.mention}")
  
  #quote command
  elif message.content.startswith(command_list[1]):
    quote = get_quote()
    await message.channel.send(quote)

  #command listing
  elif message.content.startswith(command):
    listing = '```' + '\nCommands \n------------'
    for i in range(len(command_list)):
      listing += '\n' + command_list[i] + command_description[i]
      if i == 4:
        listing += "\n\nExtras\n------------"
    listing += '\n' + '```'
    listing.format(message)
    await message.channel.send(listing)

  #add assignment command
  elif message.content.startswith(command_list[2]):
    if (len(message.content) == 4) or (len(message.content) == 5):
      await message.channel.send("Please enter an assignment!")

    else:
      assign = message.content.split(command_list[2] + ' ', 1) [1]
      update_agenda(assign)
      await message.channel.send("New assignment added: ")
      agenda = db["agenda"]
      await message.channel.send(assign)

  #delete assignment command
  elif message.content.startswith (command_list[3]):
    agenda = []
    if (len(message.content) == 4) or (len(message.content) == 5):
      await message.channel.send("Please enter the assignment number!")

    else:
      if "agenda" in db.keys():
        agenda = db["agenda"]
        index = int(message.content.split(command_list[3] + ' ', 1) [1])
        printed = agenda[index-1]
        delete_assignment(index-1)
      await message.channel.send("Assignment deleted: ")
      await message.channel.send(printed)

  #print assignment list command
  elif message.content.startswith(command_list[4]):
    keys = db['agenda']
    await message.channel.send("Printing out list:\n")
    strings = "```\n" + 'Assignments\n------------\n'
    for i in range(len(keys)):
      strings += '('+ str(i+1) + ") " + keys[i] + '\n'
    strings += '```\n'
    await message.channel.send(strings)

  #rock paper scissors
  elif message.content.startswith(command_list[5]):
    await message.channel.send("You chose to take a break!")
    time.sleep(.5)
    repeat = True
    while repeat == True:
      await message.channel.send("Please type in 'Rock', 'Paper', or 'Scissors'")

      gamemode = await client.wait_for('message')

      #rock
      if gamemode.content.lower().startswith(game[0].lower()):
        await message.channel.send("You chose: " + game[0])
        time.sleep(1)
        await message.channel.send("\nHere we go!\n")
        time.sleep(1)
        await message.channel.send("Rock... Paper... Scissors!")
        time.sleep(1)

        rand = random.randint(0,2)
        bot = game[rand]

        await message.channel.send("You:" + game[0] + "\nBeanBot:" + bot)

        if (bot == game[0]):
          await message.channel.send("It's a tie! Better luck next time!")
        elif (bot == game[1]):
          await message.channel.send("Oh, I won! That was a quick break!")
        else:
          await message.channel.send("You won! You got lucky!")
      
      #paper
      elif gamemode.content.lower().startswith(game[1].lower()):
        await message.channel.send("You chose: " + game[1])
        time.sleep(1)
        await message.channel.send("\nHere we go!\n")
        time.sleep(1)
        await message.channel.send("Rock... Paper... Scissors!")
        time.sleep(1)

        rand = random.randint(0,2)
        bot = game[rand]

        await message.channel.send("You:" + game[1] + "\nBeanBot:" + bot)

        if (bot == game[1]):
          await message.channel.send("It's a tie! Better luck next time!")
        elif (bot == game[2]):
          await message.channel.send("Oh, I won! That was a quick break!")
        else:
          await message.channel.send("You won! You got lucky!")
      
    #scissors
      elif gamemode.content.lower().startswith(game[2].lower()):
        await message.channel.send("You chose: " + game[2])
        time.sleep(1)
        await message.channel.send("\nHere we go!\n")
        time.sleep(1)
        await message.channel.send("Rock... Paper... Scissors!")
        time.sleep(1)

        rand = random.randint(0,2)
        bot = game[rand]

        await message.channel.send("You:" + game[2] + "\nBeanBot:" + bot)

        if (bot == game[2]):
          await message.channel.send("It's a tie! Better luck next time!")
        elif (bot == game[0]):
          await message.channel.send("Oh, I won! That was a quick break!")
        else:
          await message.channel.send("You won! You got lucky!")
      else:
        await message.channel.send("Please type in 'Rock', 'Paper', or 'Scissors'")

      await message.channel.send("That was fun! Would you like to play again? (Y/N)")
      reply = await client.wait_for('message')

      if (reply.content.lower() == 'y'):
        continue
      elif (reply.content.lower() == 'n'):
        await message.channel.send("Thanks for playing!")
        break

  #Chat with Bean Bot!
  elif message.content.startswith(command_list[6]):
    mess = message.content.split(command_list[6] + ' ', 1) [1]
    await message.channel.send('"'+mess+' 🦜'+ '"')

client.run(my_secret)

